public class Character {
    int strength;
    int agility;
    int intelligence;
    String name;
    String attack;

    public void sayMyName() {
        System.out.println("Hello I am " + name);
    }
    
    public void sayMyStrength() {
        System.out.println("My strength is " + strength);
    }

    void sayMyatk(){
        System.out.println("I am attacking ");
    }
}
